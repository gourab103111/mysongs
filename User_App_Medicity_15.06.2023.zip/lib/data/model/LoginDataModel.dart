
class LoginDataModel{


  String code;
  String otpVerifyEndUrl;
  String message;

  LoginDataModel({this.code, this.otpVerifyEndUrl, this.message});

  LoginDataModel.fromJson(Map<String, dynamic> json) {
  code = json['code'];
  otpVerifyEndUrl = json['otp_verify_end_url'];
  message = json['message'];
  }

  Map<String, dynamic> toJson() {
  final Map<String, dynamic> data = new Map<String, dynamic>();
  data['code'] = this.code;
  data['otp_verify_end_url'] = this.otpVerifyEndUrl;
  data['message'] = this.message;
  return data;
  }


}