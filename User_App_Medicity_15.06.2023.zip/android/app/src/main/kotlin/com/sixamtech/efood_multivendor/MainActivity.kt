package com.meddcity.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
